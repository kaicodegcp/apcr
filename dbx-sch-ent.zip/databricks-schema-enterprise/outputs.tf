output "schema_names" {
  description = "All schema names generated from schema-config/*.yaml."
  value       = local.schema_names
}

output "schema_count" {
  description = "Total number of schemas managed by this stack."
  value       = length(local.schemas)
}

output "schema_configuration" {
  description = "Resolved schema configuration used by the schema module."
  value = {
    for name, schema in local.schemas :
    name => {
      project             = schema.project
      layer               = schema.layer
      owner               = schema.owner
      enable_storage_root = schema.enable_storage_root
      properties          = schema.properties
    }
  }
}
