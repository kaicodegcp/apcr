locals {
  # ----------------------------------------------------------
  # Discover all onboarding YAML files.
  # Example:
  #   schema-config/dhubcloud.yaml
  #   schema-config/payments.yaml
  #   schema-config/risk.yaml
  # ----------------------------------------------------------
  project_files = fileset(
    "${path.module}/schema-config",
    "*.yaml"
  )

  # Decode each YAML file.
  #
  # The filename is used only as the configuration-file key.
  # The Terraform schema identity is based on project + layer.
  projects = {
    for filename in local.project_files :
    trimsuffix(filename, ".yaml") => yamldecode(
      file("${path.module}/schema-config/${filename}")
    )
  }

  # ----------------------------------------------------------
  # Generate one schema object for each project/layer.
  #
  # Stable Terraform keys:
  #   dhubcloud_brz
  #   dhubcloud_slv
  #   dhubcloud_gld
  #   payments_brz
  #   ...
  #
  # IMPORTANT:
  # Once created, do not casually rename project/layer values,
  # because the key is the Terraform resource identity.
  # ----------------------------------------------------------
  schemas = merge([
    for config_key, project in local.projects : {
      for layer in project.layers :
      "${project.project}_${layer}" => {
        name                = "${project.project}_${layer}"
        project             = project.project
        layer               = layer
        comment             = try(project.comments[layer], "${project.project} ${layer} schema")
        owner               = project.owner
        enable_storage_root = try(project.enable_storage_root, false)

        properties = merge(
          {
            environment = project.environment
            managed_by  = project.managed_by
            project     = project.project
            layer       = layer
          },
          try(project.properties, {})
        )
      }
    }
  ]...)

  # Helpful checks/output data.
  schema_names = sort(keys(local.schemas))
}
