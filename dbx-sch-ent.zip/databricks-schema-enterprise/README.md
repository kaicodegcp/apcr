# Databricks Schema Enterprise Onboarding Pattern

This repository implements a scalable Terraform pattern for managing Databricks
Unity Catalog schemas for many projects/applications using one pipeline.

## Design

Platform-managed Terraform code stays stable:

- `main.tf`
- `locals.tf`
- `variables.tf`
- `outputs.tf`

Application/project onboarding is data-driven:

- `schema-config/<project>.yaml`

A new project normally requires only a new YAML file and a normal Git pull
request. Terraform automatically discovers all `*.yaml` files with `fileset()`,
loads them with `yamldecode()`, generates stable schema keys, and passes the
combined map to the existing schema wrapper module.

## Naming

For a project:

```text
dhubcloud
```

and layers:

```text
brz
slv
gld
```

the generated schemas are:

```text
dhubcloud_brz
dhubcloud_slv
dhubcloud_gld
```

This avoids collisions when many projects use the same medallion layers.

## Recommended storage layout

When `enable_storage_root: true`, this implementation creates schema storage
roots using:

```text
<external_location_url>/<project>/<layer>
```

Example:

```text
s3://.../dhubcloud/brz
s3://.../dhubcloud/slv
s3://.../dhubcloud/gld
```

## Terraform state safety

The generated map key is:

```text
<project>_<layer>
```

Examples:

```text
dhubcloud_brz
payments_gld
```

These keys should be treated as permanent Terraform identities after creation.

Adding a new YAML project is additive.

Deleting a YAML file or removing a layer means the resource is no longer in
configuration, so Terraform can plan a destroy. Production CI/CD should always
review the plan and block delete actions unless explicitly approved.

A sample destroy-detection script is included:

```bash
terraform plan -out=tfplan
./scripts/check-plan-for-destroy.sh tfplan
terraform apply tfplan
```

## Onboard a new project

1. Copy an existing file under `schema-config/`.
2. Rename it to the new project name.
3. Update project, owner, managed_by and optional properties.
4. Run:

```bash
terraform fmt -recursive
terraform init
terraform validate
terraform plan -out=tfplan
./scripts/check-plan-for-destroy.sh tfplan
```

5. Review the plan.
6. Apply only after approval.

## Important

This package assumes the existing external-location module is already present
in the same root module and exposes:

```hcl
module.external_location.url
```

The supplied `main.tf` references that existing module exactly as in the
original implementation.

Before replacing an already-managed schema map with this design in an existing
state, first compare old and new Terraform resource addresses in `terraform
plan`. If the existing wrapper uses different `for_each` keys, migrate state
with Terraform `moved` blocks or `terraform state mv` as appropriate rather
than allowing Terraform to destroy/recreate existing schemas.
