# ------------------------------------------------------------
# Module 3: Databricks Schemas
#
# Enterprise pattern:
# - Terraform code remains unchanged for normal onboarding.
# - Project/application schema definitions live in schema-config/*.yaml.
# - All YAML files are loaded and merged automatically.
# - Stable schema keys are used to avoid accidental replacement.
# ------------------------------------------------------------

module "dbx_schema" {
  source  = "tfeiac.nam.nsroot.net/citi/terraform-databricks-dbx-schema/databricks"
  version = "0.1.0-schema1-1779906354"

  catalog_name  = var.catalog_name
  force_destroy = var.schema_force_destroy

  schemas = {
    for name, schema in local.schemas :
    name => {
      comment = schema.comment
      owner   = schema.owner

      properties = schema.properties

      storage_root = schema.enable_storage_root ? (
        "${trimsuffix(module.external_location.url, "/")}/${schema.project}/${schema.layer}"
      ) : null
    }
  }

  depends_on = [
    module.external_location
  ]
}
