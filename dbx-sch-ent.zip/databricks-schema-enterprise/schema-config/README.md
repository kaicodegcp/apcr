# Schema onboarding files

Add one YAML file per project/application.

Example:

```yaml
project: finance
environment: dev
owner: "finance-admin-group"
managed_by: "dbx-dev-finance-wksadmin-sp"
enable_storage_root: true

layers:
  - brz
  - slv
  - gld

comments:
  brz: "Finance bronze schema"
  slv: "Finance silver schema"
  gld: "Finance gold schema"

properties:
  business_unit: "finance"
```

This generates:

- `finance_brz`
- `finance_slv`
- `finance_gld`

Recommended storage layout:

- `<external_location_url>/finance/brz`
- `<external_location_url>/finance/slv`
- `<external_location_url>/finance/gld`

Do not rename an existing `project` or `layer` value casually after it has
been applied, because the resulting map key is used as the Terraform identity.

Deleting an existing YAML file removes its desired configuration and can cause
Terraform to plan deletion of the corresponding schemas. Protect production
pipelines with plan review / destroy detection.
