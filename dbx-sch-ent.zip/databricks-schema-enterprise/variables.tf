variable "catalog_name" {
  description = "Existing Unity Catalog catalog where schemas will be created."
  type        = string
}

variable "schema_force_destroy" {
  description = "Whether schema resources can be force-destroyed. Keep false for normal enterprise usage."
  type        = bool
  default     = false
}
