#!/usr/bin/env bash
set -euo pipefail

PLAN_FILE="${1:-tfplan}"

terraform show -json "${PLAN_FILE}" > tfplan.json

DELETE_COUNT="$(
  python3 - <<'PY'
import json

with open("tfplan.json", "r", encoding="utf-8") as f:
    plan = json.load(f)

count = 0

for change in plan.get("resource_changes", []):
    actions = change.get("change", {}).get("actions", [])
    if "delete" in actions:
        count += 1

print(count)
PY
)"

if [ "${DELETE_COUNT}" -gt 0 ]; then
  echo "ERROR: Terraform plan contains ${DELETE_COUNT} resource change(s) with delete actions."
  echo "Manual approval is required before apply."
  exit 1
fi

echo "OK: No Terraform delete actions detected."
